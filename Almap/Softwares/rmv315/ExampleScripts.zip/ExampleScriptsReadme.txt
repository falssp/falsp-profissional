Unzip these files into the Rename Master folder to use in the program.


"EG-Add(XofY)Counter.rmscr"
The first script shows how to add an (X/Y) style, where X is the current file number and Y is the total number of files. Even though there is a renaming step for adding a counter to a filename, this show how counters can be used in any Add step.

"EG-MoveFilesBasedOnYear.rmscr"
The second script shows how to format a date and how to create subfolders while renaming. This script will actually create a folder using the file's Year from the date modified and move the file into that folder.

"EG-SwapAroundDash.rmscr"
The third script shows how to use the file Filter, the new Remove Expression, and the ?temp? variable. In this script, all the characters before the first dash are removed and stored in the temp variable. Any leading dashes and spaces are removed. Finally, the temp variable is added to the end of the filename. This will effectively "swap" everything infront of and behind the first dash in a filename.

"EG-Create Series.rmscr"
The fourth script shows how to use a counter to make sure filenames are unique. This is similar to how Windows will add "Copy (2)" to the end of a filename.

"EG-JPEG Date.rmscr"
The fifth script shows an example of inserting JPEG tag data (EXIF). In this script, a formatted date is added to the end of the filename. This script also uses a "filter" to show only JPEG files.

"EG-MP3 Tags.rmscr"
The sixth script shows an example of inserting MP3 tag data (id3). In this script, a folder is automatically created with the artist name and each file is moved and renamed using the track number and track name. This script also uses a "filter" to show only MP3 files.